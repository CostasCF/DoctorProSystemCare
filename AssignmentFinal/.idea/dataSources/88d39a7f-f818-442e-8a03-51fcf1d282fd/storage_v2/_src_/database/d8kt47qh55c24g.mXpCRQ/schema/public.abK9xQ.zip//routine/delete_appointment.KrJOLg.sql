create function delete_appointment() returns trigger
    language plpgsql
as
$$
BEGIN
DELETE FROM "Scheduled_Appointment" WHERE "doctor_amka" = OLD."amka";
DELETE FROM "Available_Appointment" WHERE "doctor_amka" = OLD."amka";
RETURN OLD;
END;
$$;

alter function delete_appointment() owner to snzbrrltdfagct;

